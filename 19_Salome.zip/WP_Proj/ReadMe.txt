STEP1:
Run : "localhost/Project1/setup/create.php"
on the search window of your browser.(This will create your database and tables)

STEP2:
Run:
"localhost/Project1/dbit.html"
on your browser. This will redirect you to the index page. 

STEP3:
Index page has a menu with 9 options.
first is home which redirects you to the home page.
Rest 8 are used to retrieve and store data.
Each of these 8 options have 2 subwindows. 
The first window is to make a new Entry in the Resprctive Table. And Second one is for retrieving the stored Data.