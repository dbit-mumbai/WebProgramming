<?php
include "connect.php";
// Create database
$sql = "CREATE DATABASE project";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully";
	
} else {
    echo "Error creating database: " . $conn->error;
}

$conn->close();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";

// Create connection
$conn1 = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// sql to create table
$sql = "CREATE TABLE achievers (

name VARCHAR(30) NOT NULL,
email VARCHAR(30) NOT NULL,
number INT(10),year VARCHAR(2),
sub1 INT(3),sub2 INT(3),sub3 INT(3),sub4 INT(3),sub5 INT(3),sub6 INT(3),overall INT(4)
);";
$sql .= "CREATE TABLE achievements (
 
title VARCHAR(30),name VARCHAR(30)
);";
$sql .= "CREATE TABLE council (
id INT(3) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
gsm VARCHAR(30),gsf VARCHAR(30),
csm VARCHAR(30),csf VARCHAR(30),
tm VARCHAR(30),tf VARCHAR(30),
sm VARCHAR(30),sf VARCHAR(30),
prm VARCHAR(30),prf VARCHAR(30)
);";
$sql .= "CREATE TABLE project(
 
name VARCHAR(30) NOT NULL,
r1 VARCHAR(30) NOT NULL,r2 VARCHAR(30) NOT NULL,r3 VARCHAR(30) NOT NULL
 );";
$sql .= "CREATE TABLE lectures(

topic VARCHAR(30) NOT NULL,person VARCHAR(30) NOT NULL,organisation VARCHAR(30) NOT NULL,organisedby VARCHAR(30) NOT NULL,date VARCHAR(50) NOT NULL
); ";
$sql .= "CREATE TABLE certification(

topic VARCHAR(30) NOT NULL,person VARCHAR(30) NOT NULL,organisation VARCHAR(30) NOT NULL,organisedby VARCHAR(30) NOT NULL,date VARCHAR(50) NOT NULL
); ";
$sql .= "CREATE TABLE iv(
 
date VARCHAR(60) NOT NULL,location VARCHAR(30) NOT NULL,purpose VARCHAR(30) NOT NULL,organisedby VARCHAR(30) NOT NULL,number INT(4) NOT NULL,dept VARCHAR(10) NOT NULL
); ";
$sql .= "CREATE TABLE internship(
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
name VARCHAR(60) NOT NULL,organisation VARCHAR(30) NOT NULL
); ";

if ($conn1->multi_query($sql) === TRUE ) {
    echo "<br>Table created successfully";
} else {
    echo "Error creating table: " . $conn1->error;
}
/*if ($conn1->multi_query($sql1) === TRUE ) {
    echo "<br>Table created successfully";
} else {
    echo "Error creating table: " . $conn1->error;
}*/

$conn1->close();
?>
