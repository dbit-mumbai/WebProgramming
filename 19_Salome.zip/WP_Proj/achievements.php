<!DOCTYPE html>
<html>
	<head>
	<title>ACHIEVEMENTS</title>
	<style>
			body 
			{
			    background-color:   white;
			}
			table {
    				border-collapse: collapse;
    				width: 50%;
				margin-left:25%;
				border: 1px;
			}

			th, td {
   		 		text-align: left;
    				padding: 8px;
				}

			tr:nth-child(even)	
			{background-color: 	lightblue;
			opacity: 0.9;}
			tr:nth-child(odd)
			{background-color:   }

			th {
    				background-color:  grey;
    				color: white;
			}
			ul {
   				list-style-type: none;
  				  margin: 0;
  				  padding: 0;
   				 overflow: hidden;
   				 background-color: black;
			}

			li {
   			 float: left;
			}

			li a, .dropbtn {
   			 display: inline-block;
   			 color: white;
    			text-align: center;
   			 padding: 14px 16px;
    			text-decoration: none;
  
			}

			li a:hover, .dropdown:hover .dropbtn {
  			  background-color: grey;
				}

			li.dropdown {
  			  display: inline-block;
			}

			.dropdown-content {
			 opacity: 0.7;
  			 display: none;
   			 position: absolute;
   			 background-color: black;
   			 min-width: 160px;
    				box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
   			 z-index: 1;
				}

			.dropdown-content a {
   			 color: white;;
    			padding: 12px 16px;
   			text-decoration: none;
    			display: block;
   		 	text-align: left;
			}

			.dropdown-content a:hover {background-color: grey; }

			.dropdown:hover .dropdown-content {
    			display: block;opacity:0.9;
			}
			
			
			</style>

	</head>
	<body>
		<div align="center">
		<a href="http://www.dbit.in/"><img src="dbitlogo.png" alt="Don Bosco Logo" width='100%' height='140px'></img></a>
		</div>
		<hr>
		<ul>
		<li class="dropdown"><a href="dbit.html">HOME</a>
  		<li class="dropdown"><a>ACHIEVERS</a>
   	 	<div class="dropdown-content">
      		<a href="achievers.html">New Entry</a>
      		<a href="achievers1.php">Our Achievers</a>
    		</div>
		<li class="dropdown"><a>ACHIEVEMENTS</a>
   	 	<div class="dropdown-content">
      		<a href="achievements1.html">New Entry</a>
      		<a href="achievements.php">Our Achievements</a>
    		</div>
		<li class="dropdown"><a>STUDENT COUNCIL</a>
   	 	<div class="dropdown-content">
      		<a href="council1.html">New Entry</a>
      		<a href="council.php">The Council</a>
    		</div>
		<li class="dropdown"><a>CONTESTS</a>
   	 	<div class="dropdown-content">
      		<a href="project1.html">New Entry</a>
      		<a href="project.php">The Winners</a>
    		</div>
		<li class="dropdown"><a>GUEST LECTURES</a>
   	 	<div class="dropdown-content">
      		<a href="lectures1.html">New Entry</a>
      		<a href="lectures.php">Lectures Conducted</a>
    		</div>
		<li class="dropdown"><a>CERTIFICATION</a>
   	 	<div class="dropdown-content">
      		<a href="certification1.html">New Entry</a>
      		<a href="certification.php">Certifications <br>Done</a>
    		</div>
		<li class="dropdown"><a>IV</a>
   	 	<div class="dropdown-content">
      		<a href="IV1.html">New Entry</a>
      		<a href="IV.php">Our Visits</a>
    		</div>
		<li class="dropdown"><a>INTERNSHIPS</a>
   	 	<div class="dropdown-content">
      		<a href="internship1.html">New Entry</a>
      		<a href="internship.php">Our Record</a>
    		</div>
  
		</ul>
	<h1 style="text-align:center;">STUDENTS' ACHIEVEMENTS</h1>
		
	
	<br><br><br>
</body>
</html>	
	
<?php
include "cd.php";
$sql = "SELECT * FROM achievements;";
$result = $conn1->query($sql);
echo "<table>";
echo "<tr>";
echo "<th>Title of Paper</th>";
echo "<th>Name Of Conference</th>";
echo "</tr>";
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
	echo "<tr>";
        echo "<td> " . $row["title"]."</td>";
	echo "<td> " . $row["name"]."</td>";
	echo "</tr>";
    }
}
echo "</table>";

$conn1->close();
?>





