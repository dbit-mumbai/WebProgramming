<?php
include "cd.php";

$r1=$_POST['u1'];
$r2=$_POST['u2'];
$r3=$_POST['u3'];
$name=$_POST['u'];

$sql = "INSERT INTO project
VALUES ('".$name."','".$r1."','".$r2."','".$r3."');";

if ($conn1->query($sql) === TRUE) {
    echo "New record created successfully";
	header('Location: http://localhost/WP_Proj/project.php');
} else {
    echo "Error: " . $sql . "<br>" . $conn1->error;
}
$conn1->close();


?>
