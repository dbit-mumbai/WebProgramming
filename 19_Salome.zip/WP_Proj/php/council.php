<?php
include "cd.php";

$gsm=$_POST['n11'];
$gsf=$_POST['n12'];
$csm=$_POST['n21'];
$csf=$_POST['n22'];
$tm=$_POST['n31'];
$tf=$_POST['n32'];
$sm=$_POST['n41'];
$sf=$_POST['n42'];
$prm=$_POST['n51'];
$prf=$_POST['n52'];



/*
CREATE TABLE council (

gsm VARCHAR(30),gsf VARCHAR(30),
csm VARCHAR(30),csf VARCHAR(30),
tm VARCHAR(30),tf VARCHAR(30),
sm VARCHAR(30),sf VARCHAR(30),
prm VARCHAR(30),prf VARCHAR(30)
*/

$sql = "INSERT INTO council(gsm,gsf,csm,csf,tm,tf,sm,sf,prm,prf)
VALUES ('$gsm','$gsf','$csm','$csf','$tm','$tf','$sm','$sf','$prm','$prf')";

if ($conn1->query($sql) === TRUE) {
    echo "New record created successfully";
	header('Location: http://localhost/WP_Proj/council.php');
} else {
    echo "Error: " . $sql . "<br>" . $conn1->error;
}


$conn1->close();
?>
