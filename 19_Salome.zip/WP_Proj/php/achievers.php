<?php
include "cd.php";

$name=$_POST['u'];
$email=$_POST['e'];
$num=$_POST['num'];
$year=$_POST['year'];
$s1=$_POST['s1'];
$s2=$_POST['s2'];
$s3=$_POST['s3'];
$s4=$_POST['s4'];
$s5=$_POST['s5'];
$s6=$_POST['s6'];
$overall=$_POST['overall'];

$sql = "INSERT INTO achievers
VALUES ('".$name."','".$email."',".$num.",'".$year."',".$s1.",".$s2.",".$s3.",".$s4.",".$s5.",".$s6.",".$overall.")";

if ($conn1->query($sql) === TRUE) {
    echo "New record created successfully";
	header('Location: http://localhost/WP_Proj/achievers1.php');
} else {
    echo "Error: " . $sql . "<br>" . $conn1->error;
}

$conn1->close();
?>
