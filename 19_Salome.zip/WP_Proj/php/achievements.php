<?php
include "cd.php";
$name=$_POST['title'];
$u=$_POST['u'];
$sql = "INSERT INTO achievements
VALUES ('".$name."','".$u."')";

if ($conn1->query($sql) === TRUE) {
    echo "New record created successfully";
	header('Location: http://localhost/WP_Proj/achievements.php');
} else {
    echo "Error: " . $sql . "<br>" . $conn1->error;
}
$conn1->close();
?>
