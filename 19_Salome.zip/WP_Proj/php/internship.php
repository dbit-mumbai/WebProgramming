<?php
include "cd.php";



$number=$_POST['no'];
$name=$_POST['name'];
$organisation=$_POST['organisation'];


$sql = "INSERT INTO internship(name,organisation)
VALUES ('$name','$organisation');";

if ($conn1->query($sql) === TRUE) {
    echo "New record created successfully";
	header('Location: http://localhost/WP_Proj/internship.php');
} else {
    echo "Error: " . $sql . "<br>" . $conn1->error;
}		



$conn1->close();
?>
