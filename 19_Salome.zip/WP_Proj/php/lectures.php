<?php
include "cd.php";

$name=$_POST['topic_name'];
$person=$_POST['reperson'];
$organisation=$_POST['organisation'];
$organiser=$_POST['organiser'];
$date=$_POST['date'];

$sql = "INSERT INTO lectures
VALUES ('$name','$person','$organisation','$organiser','$date');";

if ($conn1->query($sql) === TRUE) {
    echo "New record created successfully";
	header('Location: http://localhost/WP_Proj/lectures.php');
} else {
    echo "Error: " . $sql . "<br>" . $conn1->error;
}


		

$conn1->close();
?>
