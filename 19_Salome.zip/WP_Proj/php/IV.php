<?php
include "cd.php";

$date=$_POST['date'];
$location=$_POST['location'];
$purpose=$_POST['purpose'];
$organiser=$_POST['organiser'];
$students=$_POST['students'];
$dept=$_POST['dept'];

$sql = "INSERT INTO iv
VALUES ('$date','$location','$purpose','$organiser',$students,'$dept');";

if ($conn1->query($sql) === TRUE) {
    echo "New record created successfully";
	header('Location: http://localhost/WP_Proj/IV.php');
} else {
    echo "Error: " . $sql . "<br>" . $conn1->error;
}		

$conn1->close();
?>
